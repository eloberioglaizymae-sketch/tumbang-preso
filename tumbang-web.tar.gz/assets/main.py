import asyncio
import pygame, math, random
pygame.init()
W, H = 900, 650
screen = pygame.display.set_mode((W, H))
pygame.display.set_caption("TUMBANG PRESO")
clock = pygame.time.Clock()
font = pygame.font.Font(None, 28)
big = pygame.font.Font(None, 64)
small = pygame.font.Font(None, 22)

GRASS = (38, 140, 38)
SKY = (135, 206, 255)
WHITE = (255, 255, 255)
BLACK = (20, 20, 20)
RED = (255, 40, 40)
YELLOW = (255, 230, 0)
BLUE = (0, 110, 255)
BROWN = (139, 90, 43)
GRAY = (160, 160, 170)

HORIZON = 400          # simula ng damo
LINE_X = 290           # linya ng tirahan
PLAYER_MIN, PLAYER_MAX = 60, 270   # hindi lalampas sa linya / controller
GROUND_Y = 560         # dito bumabagsak ang tsinelas
GRAVITY = 0.3
THROW_SPEED = 14
START_LIVES = 5        # ilang buhay sa simula (baguhin kung gusto mong mas madali o mas mahirap)

can = {"x": 600, "y": 330, "w": 45, "h": 75, "dir": 1, "fallen": False}   # x = gitna, y = taas
guard = {"x": 530, "feet": 425}
player = {"x": 120, "feet": 520, "angle": -30, "lives": START_LIVES, "hit_timer": 0}
slipper = {"x": 120, "y": 465, "vx": 0, "vy": 0, "thrown": False, "on_ground": False}

score = 0
level = 1
combo = 0
hits = 0
game_over = False
message = ""
message_timer = 0
flash_timer = 0
flash_surf = pygame.Surface((W, H), pygame.SRCALPHA)

# Controller (nasa loob ng screen ang lahat ng button)
CX, CY = W // 2, 530
R = 30
btn_up = pygame.Rect(CX - R, CY - 75 - R, R * 2, R * 2)
btn_down = pygame.Rect(CX - R, CY + 75 - R, R * 2, R * 2)
btn_left = pygame.Rect(CX - 75 - R, CY - R, R * 2, R * 2)
btn_right = pygame.Rect(CX + 75 - R, CY - R, R * 2, R * 2)
btn_throw = pygame.Rect(CX - 28, CY - 28, 56, 56)


def hand_pos():
    return player["x"] + 12, player["feet"] - 55


def can_rect():
    return pygame.Rect(can["x"] - can["w"] // 2, can["y"], can["w"], can["h"])


def guard_rect():
    return pygame.Rect(int(guard["x"]) - 14, guard["feet"] - 95, 28, 95)


def reset_slipper():
    slipper["thrown"] = False
    slipper["on_ground"] = False
    slipper["x"], slipper["y"] = hand_pos()
    slipper["vx"] = slipper["vy"] = 0


def show_message(text, duration=80):
    global message, message_timer
    message = text
    message_timer = duration


def lose_life(text):
    """Bawas buhay + pula sa screen para mas intense."""
    global combo, game_over, flash_timer
    player["lives"] -= 1
    combo = 0
    flash_timer = 20
    show_message(text, 90)
    if player["lives"] <= 0:
        game_over = True


def throw():
    if game_over:
        return
    if slipper["on_ground"]:
        reset_slipper()
        show_message("Napulot mo na ang tsinelas!", 50)
    elif not slipper["thrown"]:
        a = math.radians(player["angle"])
        slipper["x"], slipper["y"] = hand_pos()
        slipper["vx"] = math.cos(a) * THROW_SPEED
        slipper["vy"] = math.sin(a) * THROW_SPEED
        slipper["thrown"] = True


def restart_game():
    global score, level, combo, hits, game_over, flash_timer
    flash_timer = 0
    score = 0
    level = 1
    combo = 0
    hits = 0
    game_over = False
    player["lives"] = START_LIVES
    player["x"] = 120
    player["angle"] = -30
    player["hit_timer"] = 0
    can["fallen"] = False
    can["x"] = 600
    guard["x"] = 530
    reset_slipper()
    show_message("BAGONG LARO!")


def draw_person(x, feet, shirt, skin=(240, 200, 160)):
    pygame.draw.line(screen, BLACK, (x, feet - 30), (x - 12, feet), 5)       # binti
    pygame.draw.line(screen, BLACK, (x, feet - 30), (x + 12, feet), 5)
    pygame.draw.line(screen, shirt, (x, feet - 68), (x, feet - 30), 10)      # katawan
    pygame.draw.line(screen, skin, (x, feet - 62), (x - 16, feet - 42), 4)   # braso
    pygame.draw.line(screen, skin, (x, feet - 62), (x + 16, feet - 50), 4)
    pygame.draw.circle(screen, skin, (x, feet - 80), 12)                      # ulo
    pygame.draw.circle(screen, BLACK, (x, feet - 80), 12, 2)


def draw_slipper(x, y):
    pygame.draw.ellipse(screen, BROWN, (x - 11, y - 6, 22, 12))
    pygame.draw.ellipse(screen, BLACK, (x - 11, y - 6, 22, 12), 2)
    pygame.draw.line(screen, YELLOW, (x - 3, y - 5), (x + 3, y + 1), 3)


def draw_can():
    if not can["fallen"]:
        r = can_rect()
        pygame.draw.rect(screen, GRAY, r, border_radius=6)
        pygame.draw.rect(screen, RED, (r.x, r.y + 25, r.w, 22))
        pygame.draw.rect(screen, BLACK, r, 3, border_radius=6)
        pygame.draw.ellipse(screen, (110, 110, 120), (r.x, r.y - 6, r.w, 12))
    else:
        # nakahiga ang lata sa damo
        r = pygame.Rect(can["x"] - can["h"] // 2, can["y"] + can["h"] - can["w"], can["h"], can["w"])
        pygame.draw.rect(screen, GRAY, r, border_radius=6)
        pygame.draw.rect(screen, RED, (r.x + 25, r.y, 22, r.h))
        pygame.draw.rect(screen, BLACK, r, 3, border_radius=6)


def draw_controller():
    pygame.draw.rect(screen, (25, 25, 25), (CX - 150, CY - 115, 300, 230), border_radius=25)
    pygame.draw.rect(screen, (90, 90, 90), (CX - 150, CY - 115, 300, 230), 4, border_radius=25)
    for rect, d in [(btn_up, "UP"), (btn_down, "DOWN"), (btn_left, "LEFT"), (btn_right, "RIGHT")]:
        pygame.draw.circle(screen, WHITE, rect.center, R)
        pygame.draw.circle(screen, BLACK, rect.center, R, 4)
        cx, cy = rect.center
        if d == "UP":
            pygame.draw.polygon(screen, BLACK, [(cx - 12, cy + 7), (cx + 12, cy + 7), (cx, cy - 10)])
        elif d == "DOWN":
            pygame.draw.polygon(screen, BLACK, [(cx - 12, cy - 7), (cx + 12, cy - 7), (cx, cy + 10)])
        elif d == "LEFT":
            pygame.draw.polygon(screen, BLACK, [(cx + 7, cy - 12), (cx + 7, cy + 12), (cx - 10, cy)])
        else:
            pygame.draw.polygon(screen, BLACK, [(cx - 7, cy - 12), (cx - 7, cy + 12), (cx + 10, cy)])
    pygame.draw.circle(screen, RED, btn_throw.center, 28)
    pygame.draw.circle(screen, BLACK, btn_throw.center, 28, 4)
    label = "PULOT" if slipper["on_ground"] else "TIRA!"
    t = small.render(label, True, WHITE)
    screen.blit(t, (btn_throw.centerx - t.get_width() // 2, btn_throw.centery - t.get_height() // 2))


def draw_aim():
    # tuldok na nagpapakita ng tatahakin ng tsinelas
    a = math.radians(player["angle"])
    x, y = hand_pos()
    vx, vy = math.cos(a) * THROW_SPEED, math.sin(a) * THROW_SPEED
    for i in range(45):
        x += vx
        y += vy
        vy += GRAVITY
        if y >= GROUND_Y or x > W:
            break
        if i % 3 == 0:
            pygame.draw.circle(screen, WHITE, (int(x), int(y)), 3)


def draw_text_shadow(surf_font, text, color, pos):
    screen.blit(surf_font.render(text, True, BLACK), (pos[0] + 2, pos[1] + 2))
    screen.blit(surf_font.render(text, True, color), pos)


restart_game()
message = "Tamaan ang LATA! Sablay o tamaan ang TAYA = -1 buhay"
message_timer = 200

async def main():
    global score, level, combo, hits, game_over, message_timer, flash_timer
    running = True
    while running:
        # ---------- INPUT ----------
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE:
                    throw()
                elif event.key == pygame.K_r and game_over:
                    restart_game()
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if game_over:
                    restart_game()
                elif btn_throw.collidepoint(event.pos):
                    throw()

        keys = pygame.key.get_pressed()
        mouse_down = pygame.mouse.get_pressed()[0]
        mpos = pygame.mouse.get_pos()
        if not game_over:
            left = keys[pygame.K_a] or keys[pygame.K_LEFT] or (mouse_down and btn_left.collidepoint(mpos))
            right = keys[pygame.K_d] or keys[pygame.K_RIGHT] or (mouse_down and btn_right.collidepoint(mpos))
            up = keys[pygame.K_w] or keys[pygame.K_UP] or (mouse_down and btn_up.collidepoint(mpos))
            down = keys[pygame.K_s] or keys[pygame.K_DOWN] or (mouse_down and btn_down.collidepoint(mpos))
            if left:
                player["x"] -= 5
            if right:
                player["x"] += 5
            player["x"] = max(PLAYER_MIN, min(PLAYER_MAX, player["x"]))
            if not slipper["thrown"] and not slipper["on_ground"]:
                if up:
                    player["angle"] -= 1.5
                if down:
                    player["angle"] += 1.5
                player["angle"] = max(-70, min(45, player["angle"]))
                slipper["x"], slipper["y"] = hand_pos()

        # ---------- UPDATE ----------
        if not game_over:
            # gumagalaw na lata
            if not can["fallen"]:
                can["x"] += can["dir"] * (1.5 + level * 0.6)
                if can["x"] > 750:
                    can["x"] = 750
                    can["dir"] = -1
                elif can["x"] < 380:
                    can["x"] = 380
                    can["dir"] = 1

            # taya (guard)
            if can["fallen"]:
                target, sp = can["x"], 6
            else:
                target, sp = can["x"] + 70, 2.5 + level * 0.3   # nasa likod ng lata ang taya
            guard["x"] += max(-sp, min(sp, target - guard["x"]))
            guard["x"] = max(320, min(840, guard["x"]))
            if can["fallen"] and abs(guard["x"] - can["x"]) < 15:
                can["fallen"] = False
                show_message("Inayos ng Taya!")

            if player["hit_timer"] > 0:
                player["hit_timer"] -= 1

            # huli ka kapag malapit ka sa taya
            if abs(guard["x"] - player["x"]) < 55 and player["hit_timer"] == 0:
                player["hit_timer"] = 90
                player["x"] = 100
                reset_slipper()
                guard["x"] += 60
                lose_life("NAHULI KA NG TAYA! -1 BUHAY")

            # lipad ng tsinelas
            if slipper["thrown"]:
                slipper["x"] += slipper["vx"]
                slipper["y"] += slipper["vy"]
                slipper["vy"] += GRAVITY
                srect = pygame.Rect(slipper["x"] - 9, slipper["y"] - 6, 18, 12)
                if srect.colliderect(guard_rect()):
                    # natamaan ang taya = bawas buhay
                    slipper["thrown"] = False
                    slipper["on_ground"] = True
                    slipper["x"], slipper["y"] = guard["x"], GROUND_Y
                    lose_life("NATAMAAN MO ANG TAYA! -1 BUHAY")
                elif not can["fallen"] and srect.colliderect(can_rect()):
                    can["fallen"] = True
                    combo += 1
                    points = 10 * combo
                    score += points
                    hits += 1
                    new_level = 1 + hits // 3
                    msg = f"TUMBA! +{points}"
                    if new_level > level:
                        level = new_level
                        msg += f"   LEVEL {level}!"
                    show_message(msg, 100)
                    slipper["thrown"] = False
                    slipper["on_ground"] = True
                    slipper["x"], slipper["y"] = can["x"], GROUND_Y
                elif slipper["y"] >= GROUND_Y or slipper["x"] > W - 15 or slipper["x"] < 15:
                    slipper["thrown"] = False
                    slipper["on_ground"] = True
                    slipper["x"] = max(20, min(W - 20, slipper["x"]))
                    slipper["y"] = GROUND_Y
                    lose_life("SABLAY! -1 BUHAY (pindutin ang PULOT)")

        if message_timer > 0:
            message_timer -= 1

        # ---------- DRAW ----------
        screen.fill(SKY)
        pygame.draw.circle(screen, YELLOW, (820, 70), 40)
        pygame.draw.rect(screen, GRASS, (0, HORIZON, W, H - HORIZON))
        for y in range(HORIZON + 30, H, 24):               # tuldok-tuldok na linya ng tirahan
            pygame.draw.line(screen, WHITE, (LINE_X, y - 12), (LINE_X, y), 3)
        draw_text_shadow(small, "LINYA", WHITE, (LINE_X - 20, HORIZON + 6))

        draw_can()
        draw_person(int(guard["x"]), guard["feet"], YELLOW)
        if player["hit_timer"] == 0 or (player["hit_timer"] // 6) % 2 == 0:
            draw_person(int(player["x"]), player["feet"], BLUE)
        if not slipper["thrown"] and not slipper["on_ground"] and not game_over:
            draw_aim()
        draw_slipper(int(slipper["x"]), int(slipper["y"]))

        # HUD
        draw_text_shadow(font, f"Score: {score}", WHITE, (15, 12))
        draw_text_shadow(font, f"Level: {level}", WHITE, (15, 42))
        if combo > 1:
            draw_text_shadow(font, f"Combo x{combo}", YELLOW, (15, 72))
        draw_text_shadow(font, "Buhay:", WHITE, (W - 235, 12))
        for i in range(max(0, player["lives"])):
            pygame.draw.circle(screen, RED, (W - 160 + i * 28, 24), 11)
            pygame.draw.circle(screen, BLACK, (W - 160 + i * 28, 24), 11, 2)
        if message_timer > 0:
            t = font.render(message, True, WHITE)
            draw_text_shadow(font, message, WHITE, (W // 2 - t.get_width() // 2, 110))

        draw_controller()

        if flash_timer > 0:
            flash_surf.fill((255, 0, 0, min(110, flash_timer * 8)))
            screen.blit(flash_surf, (0, 0))
            flash_timer -= 1

        if game_over:
            overlay = pygame.Surface((W, H), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 170))
            screen.blit(overlay, (0, 0))
            t1 = big.render("GAME OVER", True, RED)
            t2 = font.render(f"Final Score: {score}   Level: {level}", True, WHITE)
            t3 = font.render("Pindutin ang R o i-click para maglaro ulit", True, YELLOW)
            screen.blit(t1, (W // 2 - t1.get_width() // 2, 220))
            screen.blit(t2, (W // 2 - t2.get_width() // 2, 295))
            screen.blit(t3, (W // 2 - t3.get_width() // 2, 340))

        pygame.display.flip()
        clock.tick(60)
        await asyncio.sleep(0)   # kailangan ng pygbag
    pygame.quit()


asyncio.run(main())